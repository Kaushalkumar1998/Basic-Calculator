from ldm.modules.image_degradation.bsrgan import (
    degradation_bsrgan_variant as degradation_fn_bsr,
)
from ldm.modules.image_degradation.bsrgan_light import (
    degradation_bsrgan_variant as degradation_fn_bsr_light,
)
