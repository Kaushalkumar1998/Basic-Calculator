'''
Initialization file for the ldm.invoke.restoration package
'''
from .base import Restoration
