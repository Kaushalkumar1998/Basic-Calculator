'''
Initialization file for the ldm.invoke.generator package
'''
from .base import Generator
