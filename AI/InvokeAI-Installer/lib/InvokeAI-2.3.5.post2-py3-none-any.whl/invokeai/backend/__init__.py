'''
Initialization file for invokeai.backend
'''
from .invoke_ai_web_server import InvokeAIWebServer

